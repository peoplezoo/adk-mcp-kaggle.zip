from fastapi import FastAPI
from pydantic import BaseModel
from typing import Dict, Any
import importlib

app = FastAPI()

TOOL_IMPLS = {
    "tool_specify": ("adk_app.tools.tool_specify", "tool_specify"),
    "tool_codegen": ("adk_app.tools.tool_codegen", "tool_codegen"),
    "tool_sandbox_run": ("adk_app.tools.tool_sandbox_run", "tool_sandbox_run"),
    "tool_register": ("adk_app.tools.tool_register", "tool_register"),
}

class MCPCall(BaseModel):
    name: str
    arguments: Dict[str, Any] = {}

@app.post("/mcp/call")
def call_tool(inp: MCPCall):
    if inp.name not in TOOL_IMPLS:
        return {"isError": True, "message": f"unknown tool {inp.name}"}
    mod_name, fn_name = TOOL_IMPLS[inp.name]
    mod = importlib.import_module(mod_name)
    fn = getattr(mod, fn_name)
    try:
        return fn(**(inp.arguments or {}))
    except Exception as e:
        return {"isError": True, "message": str(e)}
