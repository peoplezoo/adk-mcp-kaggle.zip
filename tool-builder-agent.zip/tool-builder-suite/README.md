# Tool Builder Agent (ADK/MCP-ready demo)

Turns a task description into a runnable tool:
1) `tool_specify` derives name, I/O schema, and oracle tests.
2) `tool_codegen` emits Python code.
3) `tool_sandbox_run` executes tests in a temp dir.
4) `tool_register` writes schema + files to a registry.

## Run
```
uvicorn adk_app.app:app --host 0.0.0.0 --port 8080 &
uvicorn mcp_server.server:app --host 0.0.0.0 --port 8081 &
```

## Build a tool end-to-end
POST /adk/build_tool
```json
{ "task_text": "Given a CSV file, compute basic stats per column" }
```
Response contains spec, codegen, sandbox test results, and registration info (if tests pass).
