import json, textwrap

def tool_codegen(spec: dict, language: str = "python") -> dict:
    name = spec["name"]
    if language != "python":
        return {"isError": True, "message": "only python generation supported in this demo"}
    # Generate implementation stubs for known types
    if name == "csv_summary":
        body = '''import pandas as pd, os, json
def csv_summary(path: str, sep: str = ',') -> dict:
    if not os.path.exists(path):
        return {"isError": True, "message": f"not found: {path}"}
    df = pd.read_csv(path, sep=sep)
    desc = df.describe(include='all').to_dict()
    return {"columns": df.columns.tolist(), "n": int(df.shape[0]), "describe": desc}
'''
    elif name == "http_get_text":
        body = '''import httpx
def http_get_text(url: str, timeout_sec: int = 20) -> dict:
    with httpx.Client(timeout=timeout_sec, follow_redirects=True) as s:
        r = s.get(url)
    ct = (r.headers.get("content-type") or "").lower()
    out = {"status": r.status_code, "headers": dict(r.headers)}
    if "html" in ct or "text" in ct or "json" in ct:
        out["text_preview"] = r.text[:2000]
    return out
'''
    else:
        body = f'''def {name}(payload: dict) -> dict:
    return {{"payload": payload}}
'''
    path = f"generated/{name}.py"
    files = [{"path": path, "content": body}]
    return {"files": files, "entrypoint": path, "build_cmd": ""}
