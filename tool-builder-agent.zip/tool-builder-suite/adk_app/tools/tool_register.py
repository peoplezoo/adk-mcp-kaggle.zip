import os, json, hashlib

REG_DIR = "/tmp/tool_registry"
os.makedirs(REG_DIR, exist_ok=True)

def tool_register(schema: dict, files: list[dict], entrypoint: str) -> dict:
    # save schema
    name = schema["name"]
    spath = os.path.join(REG_DIR, f"{name}.json")
    with open(spath, "w", encoding="utf-8") as f: json.dump(schema, f, indent=2)
    # save files
    wdir = os.path.join(REG_DIR, name)
    os.makedirs(wdir, exist_ok=True)
    for f in files:
        p = os.path.join(wdir, f["path"])
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as h: h.write(f["content"])
    return {"tool_id": name, "version": schema.get("version","0.1.0"), "schema_path": spath, "files_dir": wdir, "entrypoint": entrypoint}
