import re, json

def _infer_io(task_text: str):
    # crude heuristics for common tasks
    if "csv" in task_text.lower() and "stats" in task_text.lower():
        return {
            "name": "csv_summary",
            "input_schema": {
                "type": "object",
                "properties": {"path": {"type":"string"}, "sep":{"type":["string","null"],"default":","}},
                "required": ["path"]
            },
            "description": "Load a CSV and return basic statistics for numeric columns."
        }
    if "http" in task_text.lower() or "url" in task_text.lower():
        return {
            "name": "http_get_text",
            "input_schema": {
                "type": "object",
                "properties": {"url": {"type":"string"}, "timeout_sec":{"type":"integer","default":20}},
                "required": ["url"]
            },
            "description": "Fetch a URL and return status, headers, and first 2KB of text."
        }
    # default echo tool
    return {
        "name": "echo_kv",
        "input_schema": {
            "type": "object",
            "properties": {"payload":{"type":"object"}},
            "required": ["payload"]
        },
        "description": "Echo inputs back as JSON."
    }

def tool_specify(task_text: str) -> dict:
    base = _infer_io(task_text)
    tests = []
    if base["name"] == "csv_summary":
        tests = [{"input":{"path":"sample.csv","sep":","}, "expect":{"keys":["columns","describe"]}}]
    elif base["name"] == "http_get_text":
        tests = [{"input":{"url":"https://example.com"}, "expect":{"keys":["status","headers","text_preview"]}}]
    else:
        tests = [{"input":{"payload":{"a":1}}, "expect":{"keys":["payload"]}}]
    return {"name": base["name"], "description": base["description"], "input_schema": base["input_schema"], "oracle_tests": tests}
