import os, importlib.util, json, tempfile, time, traceback

def _load_func(py_path: str, func_name: str):
    spec = importlib.util.spec_from_file_location("mod", py_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore
    return getattr(mod, func_name)

def tool_sandbox_run(files: list[dict], cmd: str = "", tests: list[dict] | None = None, limits: dict | None = None, entrypoint: str | None = None) -> dict:
    limits = limits or {"cpu_sec": 5, "mem_mb": 512, "net": False}
    tests = tests or []
    with tempfile.TemporaryDirectory() as td:
        # materialize files
        for f in files:
            p = os.path.join(td, f["path"])
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf-8") as h: h.write(f["content"])
        # import and run tests
        func_name = os.path.splitext(os.path.basename(entrypoint or files[0]["path"]))[0]
        fn = _load_func(os.path.join(td, entrypoint or files[0]["path"]), func_name)
        failures = []
        for i, t in enumerate(tests):
            try:
                out = fn(**t["input"])
                # simple validator: ensure keys exist
                expect = t.get("expect", {})
                keys = expect.get("keys", [])
                missing = [k for k in keys if k not in (out or {})]
                if missing:
                    failures.append({"test_idx": i, "message": f"missing keys: {missing}", "out": out})
            except Exception as e:
                failures.append({"test_idx": i, "message": str(e), "trace": traceback.format_exc()})
        return {"pass": len(failures) == 0, "failures": failures, "metrics": {"wall_ms": 0}}
