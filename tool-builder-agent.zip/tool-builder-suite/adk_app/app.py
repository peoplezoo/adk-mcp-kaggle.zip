import os, json
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Dict, Any, List

# ---- ADK shim ----
class Tool:
    def __init__(self, fn): self.fn = fn
class LlmAgent:
    def __init__(self, model: str, tools: list):
        self.model = model
        self.tools = {t.fn.__name__: t.fn for t in tools}
    def call(self, name: str, **kwargs):
        return self.tools[name](**kwargs)

# ---- Tool Builder tools ----
from adk_app.tools.tool_specify import tool_specify
from adk_app.tools.tool_codegen import tool_codegen
from adk_app.tools.tool_sandbox_run import tool_sandbox_run
from adk_app.tools.tool_register import tool_register

agent = LlmAgent(
    model=os.getenv("ADK_MODEL","gemini-2.5-flash"),
    tools=[Tool(tool_specify), Tool(tool_codegen), Tool(tool_sandbox_run), Tool(tool_register)],
)

app = FastAPI()

class CallIn(BaseModel):
    tool: str
    args: Dict[str, Any] = {}

class BuildIn(BaseModel):
    task_text: str
    language: str = "python"
    limits: Dict[str, Any] = {"cpu_sec": 5, "mem_mb": 512, "net": False}

@app.post("/adk/call")
async def adk_call(inp: CallIn):
    try:
        out = agent.call(inp.tool, **(inp.args or {}))
        return JSONResponse(out)
    except KeyError:
        return JSONResponse({"isError": True, "message": f"unknown tool {inp.tool}"}, status_code=404)
    except Exception as e:
        return JSONResponse({"isError": True, "message": str(e)}, status_code=500)

@app.post("/adk/build_tool")
async def build_tool(inp: BuildIn):
    # 1) specify
    spec = agent.call("tool_specify", task_text=inp.task_text)
    if spec.get("isError"): return JSONResponse(spec, status_code=400)
    # 2) codegen
    gen = agent.call("tool_codegen", spec=spec, language=inp.language)
    if gen.get("isError"): return JSONResponse(gen, status_code=400)
    # 3) sandbox run
    sand = agent.call("tool_sandbox_run", files=gen["files"], cmd=gen.get("build_cmd",""), tests=spec.get("oracle_tests",[]), limits=inp.limits, entrypoint=gen["entrypoint"])
    # 4) register if pass
    reg = None
    if sand.get("pass"):
        schema = {
            "name": spec["name"],
            "title": spec.get("description","Generated tool"),
            "description": spec.get("description","Generated tool"),
            "inputSchema": spec["input_schema"],
            "outputSchema": {"type":"object"},  # minimal
            "version": "0.1.0"
        }
        reg = agent.call("tool_register", schema=schema, files=gen["files"], entrypoint=gen["entrypoint"])
    return JSONResponse({"spec": spec, "codegen": gen, "sandbox": sand, "registration": reg})

@app.get("/health")
async def health():
    return {"status":"ok", "model": agent.model, "tools": list(agent.tools.keys())}
